$(function () {
        if (!sessionStorage.ttoken || sessionStorage.ttoken === null)
                location.href = "login.html";

        //$("#idSpan").val = sessionStorage.ttoken;
        document.getElementById("idSpan").innerHTML = sessionStorage.ttoken;


        var link1 = crossroads.addRoute("/logout", function () {
                sessionStorage.clear();
                location.href = "login.html";
        });

        var link2 = crossroads.addRoute("", function () {
                $("#divHome").show();
                $("#divAccount").hide();
                $("#divAbout").hide();
        });

        var link6 = crossroads.addRoute("/about", function () {
                $("#divAbout").show();
                $("#divHome").hide();
        });

        var link4 = crossroads.addRoute("/btnAddAccount", function () {
                $("#divHome").hide();
                $("#divAccount").hide();
                $("#divAddAccount").show();
                $("#divEditAccount").hide();
                $("#divAbout").hide();
                
        });


        var link3 = crossroads.addRoute("/account", function () {
                $(".navbar-collapse li").removeClass("active");
                $(".navbar-collapse li a[href='#account']").parent().addClass("active");
                var email = sessionStorage.ttoken;
                var datalist = "email=" + email;
                $.ajax({
                        type: "post",
                        url: "http://192.168.1.14:8080/sabnad_group7/GetAccountData",
                        data: datalist,
                        cache: false,
                        success: function (mydata) {
                                var myData = JSON.parse(mydata);
                                //alert(mydata);
                                var lastIndex = myData.length - 1;
                                var htmlText = "";
                                if (myData[lastIndex].status === 1) {
                                        for (var i = 0; i < lastIndex; i++) {
                                                htmlText = htmlText + "<tr><td>" + myData[i].id
                                                        + "</td><td><a href='#viewaccount/" + myData[i].id + "'>" + myData[i].accname
                                                        + "</a></td><td>" + myData[i].username
                                                        + "</td><td>" + myData[i].password
                                                        + "</td><td>" + myData[i].email
                                                        + "</td><td><a href='#delaccount'><span class='glyphicon glyphicon-trash'data-accountid="
                                                        + myData[i].id
                                                        + "></span></a></td></tr>";
                                        }
                                        $("#tblAccount tbody").html(htmlText);
                                }
                        },
                        error: function () {
                                console.log("ajax error!");
                                alert("Please contact admin!");
                        }
                });
                $("#divHome").hide();
                $("#divAccount").show();
                $("#divEditAccount").hide();
                $("#divAddAccount").hide();
                $("#divAbout").hide();
        });

        var link5 = crossroads.addRoute("/viewaccount/{id}", function(id){


                var datalist = "id=" +id;
                $.ajax({
                        type: "post",
                        url: "http://192.168.1.14:8080/sabnad_group7/GetAccountById",
                        data: datalist,
                        cache: false,
                        success: function (mydata) {
                                var myData = JSON.parse(mydata);

                                if (myData.status === 1) {
                                        
                                        document.getElementById("aname").value = myData.accname;
                                        document.getElementById("fname100").value = myData.username;
                                        document.getElementById("pass100").value = myData.password;
                                        document.getElementById("emailadd100").value = myData.email;
                                        document.getElementById("accountid").value = myData.id;
                                }
                                $("#divHome").hide();
                                $("#divAccount").hide();
                                $("#divAddAccount").hide();
                                $("#divEditAccount").show();
                                $("#divAbout").hide();
                        },
                        error: function () {
                                console.log("ajax error!");
                                alert("Please contact admin!");
                        }
                });

        
        });

        $("#frmAddAccount").submit(function (e) {
                e.preventDefault();
                e.stopPropagation();

                var accname = $("#accname").val();
                var username = $("#username").val();
                var password = $("#password").val();
                var email = $("#email").val();

                var datalist = "accname=" + accname +"&username=" + username + "&password=" + password + "&email=" + email + "&ownerEmail=" + sessionStorage.ttoken;
                $.ajax({
                        type: "post",
                        url: "http://192.168.1.14:8080/sabnad_group7/AddAccount",
                        data: datalist,
                        cache: false,
                        success: function (mydata) {
                                var myData = JSON.parse(mydata);
                                if (myData.status === 1) {
                                        alert("Add Account Success!");
                                        $("#divAddAccount").hide();
                                        $("#divAccount").hide();
                                        
                                        
                                }
                                else {
                                        alert("Add Account Failed");
                                }
                               
                        },
                        error: function () {
                                console.log("ajax error!");
                                alert("Please contact admin!");
                        }
                });
               
        });

        $("#frmEditAccount").submit(function (e) {
                e.preventDefault();
                e.stopPropagation();

                var accname = $("#aname").val();
                var username = $("#fname100").val();
                var password = $("#pass100").val();
                var emailadd = $("#emailadd100").val();
                var accountid = $("#accountid").val();

                var datalist = "accname=" + accname  +"&username=" + username  + "&password=" + password + "&email=" + emailadd + "&accountid=" + accountid;
                $.ajax({
                        type: "post",
                        url: "http://192.168.1.14:8080/sabnad_group7/UpdateAccountById",
                        data: datalist,
                        cache: false,
                        success: function (mydata) {
                                var myData = JSON.parse(mydata);
                                if (myData.status === 1) {
                                        alert("Edit Account Success!");
                                        $("#divEditAccount").hide();
                                        
                                        
                                }
                                else {
                                        alert("Edit Account Failed");
                                }
                                
                        },
                        error: function () {
                                console.log("ajax error!");
                                alert("Please contact admin!");
                        }
                });
                  
        });


        $("#tblAccount tbody").on("click","span",function(){
                var accountid=$(this).data("accountid")
               //bootbox.alert("Delete Process Index "+contactid);
               datalist="accountid="+accountid;
                var parentTR = $(this).parent().parent().parent();
                bootbox.confirm("Are you sure to delete this account?",function(answer){
                        if(answer){
                                $.ajax({
                                        type: "post",
                                        url: "http://192.168.1.14:8080/sabnad_group7/DelAccountById",
                                        data: datalist,
                                        cache: false,
                                        success: function (mydata) {
                                                var myData = JSON.parse(mydata);
                                                if (myData.status === 1) {
                                                        alert("Delete Account Successfull!");
                                                        $(parentTR).fadeOut("slow","swing",function(){
                                                                $(parentTR).remove();
                                                        });
                                                }
                                                else {
                                                        alert("Delete Account Failed");
                                                }
                                        },
                                        error: function () {
                                                console.log("ajax error!");
                                                alert("Please contact admin!");
                                        }
                                });
                        }else{
                                bootbox.alert("Delete Canceled")
                        }

                });
        });
        function parseHash(newHash, oldHash) {
                crossroads.parse(newHash);

        }

        hasher.initialized.add(parseHash);
        hasher.changed.add(parseHash);
        hasher.init();

});